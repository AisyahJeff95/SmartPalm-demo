#!/usr/bin/env python3
"""
compile_all.py
Combines index.html, comprehensive.html, standard.html, PalmnexReaDS.html
into a single self-contained compiled.html with:
  - All pages as show/hide <div> sections
  - Internal JS router (no page reloads)
  - All CDN JS/CSS inlined
  - All local CSS inlined
  - All local images base64 embedded
"""

import base64
import mimetypes
import os
import re
import urllib.request
from html.parser import HTMLParser

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
OUTPUT_FILE = os.path.join(BASE_DIR, "compiled.html")

CDN_CACHE = {}

PAGES = [
    ("home",          "index.html",          "Home"),
    ("comprehensive", "comprehensive.html",   "Comprehensive Fert"),
    ("standard",      "standard.html",        "Standard Fert"),
    ("reada",         "PalmnexReaDS.html",    "PalmNexReaDS"),
]

# ── helpers ──────────────────────────────────────────────────────────────────

def fetch_cdn(url):
    if url in CDN_CACHE:
        return CDN_CACHE[url]
    print(f"    Fetching CDN: {url}")
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=45) as resp:
            content = resp.read().decode("utf-8", errors="replace")
        CDN_CACHE[url] = content
        return content
    except Exception as e:
        print(f"    WARNING: Could not fetch {url}: {e}")
        return None

def image_to_data_uri(filepath):
    mime, _ = mimetypes.guess_type(filepath)
    if not mime:
        ext = os.path.splitext(filepath)[1].lower()
        mime = {".png":"image/png",".jpg":"image/jpeg",".jpeg":"image/jpeg",
                ".gif":"image/gif",".svg":"image/svg+xml",
                ".ico":"image/x-icon"}.get(ext,"application/octet-stream")
    with open(filepath,"rb") as f:
        data = base64.b64encode(f.read()).decode("ascii")
    return f"data:{mime};base64,{data}"

def read_local_file(path):
    with open(path,"r",encoding="utf-8",errors="replace") as f:
        return f.read()

LOCAL_IMAGES = [
    "MPOB-3-all-black-fonts.png","MPOB-3.png","MPOB-3_transparent.png",
    "home-logo-final.png","comp-logo-final.png","std-logo-final.png",
    "reada-logo-final.png","report_photo_new.png","palm_block_satellite.png",
    "full_map_nutrient_detection.png","block22_permanent_photo.png",
    "ChatGPT Image Sep 22, 2026 at 11_06_29 PM.png",
    "ChatGPT Image Sep 22, 2026 at 11_11_55 PM.png",
]

# Pre-build image map once
IMAGE_MAP = {}
for img in LOCAL_IMAGES:
    full = os.path.join(BASE_DIR, img)
    if os.path.isfile(full):
        IMAGE_MAP[img] = image_to_data_uri(full)
        print(f"  Encoded image: {img}")

def inline_images(html):
    for img, data_uri in IMAGE_MAP.items():
        html = html.replace(f'src="{img}"', f'src="{data_uri}"')
        html = html.replace(f"src='{img}'", f"src='{data_uri}'")
    return html

def inline_local_css(html):
    def replace_local_css(m):
        href = m.group(1)
        if href.startswith("http") or href.startswith("//"):
            return m.group(0)
        full = os.path.join(BASE_DIR, href.replace("/", os.sep))
        if os.path.isfile(full):
            print(f"    Inlining local CSS: {href}")
            css = read_local_file(full)
            return f"<style>\n{css}\n</style>"
        return m.group(0)
    return re.sub(r'<link[^>]+href="([^"]+\.css)"[^>]*/?>',replace_local_css,html)

def inline_cdn_css(html):
    def replace_cdn_css(m):
        href = m.group(1)
        content = fetch_cdn(href)
        if content:
            return f"<style>\n/* {href} */\n{content}\n</style>"
        return m.group(0)
    return re.sub(r'<link[^>]+href="(https?://[^"]+\.css)"[^>]*/?>',replace_cdn_css,html)

def inline_cdn_js(html):
    def replace_cdn_js(m):
        src = m.group(1)
        content = fetch_cdn(src)
        if content:
            return f"<script>\n/* {src} */\n{content}\n</script>"
        return m.group(0)
    return re.sub(r'<script\s+src="(https?://[^"]+)"[^>]*>\s*</script>',replace_cdn_js,html)

def inline_local_js(html):
    """Inline <script src="js/..."> local scripts."""
    def replace_local_js(m):
        src = m.group(1)
        full = os.path.join(BASE_DIR, src.replace("/", os.sep))
        if os.path.isfile(full):
            print(f"    Inlining local JS: {src}")
            js = read_local_file(full)
            return f"<script>\n{js}\n</script>"
        return m.group(0)
    return re.sub(r'<script\s+src="(js/[^"]+)"[^>]*>\s*</script>',replace_local_js,html)

def extract_body(html):
    """Extract content between <body...> and </body>."""
    m = re.search(r'<body[^>]*>(.*?)</body>', html, re.DOTALL | re.IGNORECASE)
    return m.group(1).strip() if m else html

def extract_head_resources(html):
    """Extract all <link> and <script> tags from <head>."""
    m = re.search(r'<head[^>]*>(.*?)</head>', html, re.DOTALL | re.IGNORECASE)
    return m.group(1).strip() if m else ""

def fix_nav_links(html):
    """Replace all page-to-page navigation with internal router calls."""
    mapping = {
        "index.html":          "navigateTo('home')",
        "comprehensive.html":  "navigateTo('comprehensive')",
        "standard.html":       "navigateTo('standard')",
        "PalmnexReaDS.html":   "navigateTo('reada')",
    }
    # Replace href="page.html" with href="#" onclick="navigateTo('...')"
    for page, fn in mapping.items():
        html = html.replace(f'href="{page}"', f'href="#" onclick="{fn}; return false;"')
        # onclick="location.href='page.html'"
        html = html.replace(f"location.href='{page}'", f"{fn}")
        html = html.replace(f'location.href="{page}"', f'{fn}')
        # handleProtectedCardClick('page.html')  -> keep the protection, just swap URL
        page_id_val = fn.split("'")[1]
        html = html.replace(f"handleProtectedCardClick('{page}')", f"handleProtectedCardClick('{page_id_val}')")
    return html

def dedup_scripts(html):
    """Remove duplicate <script>...</script> blocks (keep first occurrence)."""
    seen = set()
    def dedup(m):
        key = m.group(1).strip()[:200]  # fingerprint by first 200 chars
        if key in seen:
            return "<!-- duplicate script removed -->"
        seen.add(key)
        return m.group(0)
    return re.sub(r'<script[^>]*>(.*?)</script>', dedup, html, flags=re.DOTALL)

# ── main ─────────────────────────────────────────────────────────────────────

def main():
    # ── Step 1: process comprehensive.html as the "base" ────────────────────
    # It already has the most complete CSS/JS; we'll use its <head> as the
    # foundation and extract body sections from all pages.

    print("\n=== Reading files ===")
    page_htmls = {}
    for page_id, filename, _ in PAGES:
        path = os.path.join(BASE_DIR, filename)
        if not os.path.isfile(path):
            print(f"  WARNING: {filename} not found, skipping.")
            page_htmls[page_id] = ""
        else:
            print(f"  Reading {filename} ({os.path.getsize(path)//1024} KB)")
            page_htmls[page_id] = read_local_file(path)

    print("\n=== Inlining resources in each page ===")
    processed = {}
    for page_id, filename, label in PAGES:
        print(f"\n  [{page_id}]")
        html = page_htmls[page_id]
        html = inline_local_css(html)
        html = inline_cdn_css(html)
        html = inline_cdn_js(html)
        html = inline_local_js(html)
        html = inline_images(html)
        html = fix_nav_links(html)
        processed[page_id] = html

    print("\n=== Building unified HTML ===")

    # Use comprehensive as base (richest head)
    base_html = processed["comprehensive"]

    # Extract <head> from base
    head_match = re.search(r'<head[^>]*>(.*?)</head>', base_html, re.DOTALL | re.IGNORECASE)
    head_content = head_match.group(1) if head_match else ""

    # Extract <body> from each page
    bodies = {}
    for page_id, _, _ in PAGES:
        bodies[page_id] = extract_body(processed[page_id])

    # Collect any extra <style>/<script> tags from non-base pages' heads
    extra_head = ""
    for page_id, _, _ in PAGES:
        if page_id == "comprehensive":
            continue
        h = extract_head_resources(processed[page_id])
        # Only grab <style> blocks (scripts already inlined in body processing)
        for style_m in re.finditer(r'<style[^>]*>.*?</style>', h, re.DOTALL):
            extra_head += "\n" + style_m.group(0)

    # Build page sections
    page_sections = ""
    for page_id, filename, label in PAGES:
        display = "block" if page_id == "home" else "none"
        page_sections += f"""
<!-- ═══════ PAGE: {label} ═══════ -->
<div id="page-section-{page_id}" class="compiled-page-section" style="display:{display}; width:100%; height:100%;">
{bodies[page_id]}
</div>
"""

    # Build the internal router JS
    router_js = """
<script>
// ── Compiled SPA Router ──────────────────────────────────────────
var _PAGES = ['home','comprehensive','standard','reada'];
var _currentPage = 'home';

function navigateTo(pageId) {
    if (!_PAGES.includes(pageId)) return;
    // Hide all
    _PAGES.forEach(function(p) {
        var el = document.getElementById('page-section-' + p);
        if (el) el.style.display = 'none';
    });
    // Show target
    var target = document.getElementById('page-section-' + pageId);
    if (target) target.style.display = 'block';

    // Update sidebar active state (works across all pages' sidebars)
    document.querySelectorAll('.cms-nav-item').forEach(function(a) {
        a.classList.remove('active');
    });
    document.querySelectorAll('.cms-nav-item').forEach(function(a) {
        var onclick = a.getAttribute('onclick') || a.getAttribute('href') || '';
        if (onclick.includes("'" + pageId + "'")) {
            a.classList.add('active');
        }
    });

    _currentPage = pageId;

    // Trigger map invalidation when switching to map pages
    setTimeout(function() {
        if (typeof mapComp !== 'undefined' && mapComp) {
            try { mapComp.invalidateSize(); } catch(e){}
        }
        if (typeof mapStd !== 'undefined' && mapStd) {
            try { mapStd.invalidateSize(); } catch(e){}
        }
    }, 150);
}

// Handle protected card (ReaDS) clicks
function handleProtectedCardClick(pageId) {
    navigateTo(pageId);
}

// Override location.href changes to internal pages
(function() {
    var _origAssign = window.location.assign.bind(window.location);
    // Intercept card onclick="location.href='...'" via MutationObserver or just override
})();
</script>
"""

    # Full compiled output
    out = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>SmartPalm - PalmNex Dashboard</title>
{head_content}
{extra_head}
<style>
/* ── Compiled SPA layout ── */
html, body {{
    margin: 0; padding: 0; width: 100%; height: 100%;
    overflow: hidden;
}}
.compiled-page-section {{
    position: absolute;
    top: 0; left: 0;
    width: 100%;
    height: 100%;
    overflow: auto;
}}
</style>
</head>
<body style="position:relative; width:100%; height:100vh; overflow:hidden;">
{page_sections}
{router_js}
</body>
</html>
"""

    print("\n=== Deduplicating scripts ===")
    out = dedup_scripts(out)

    print(f"\n=== Writing {OUTPUT_FILE} ===")
    with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
        f.write(out)

    kb = os.path.getsize(OUTPUT_FILE) // 1024
    print(f"\n✅ Done! compiled.html = {kb} KB ({kb//1024} MB)")

if __name__ == "__main__":
    main()
